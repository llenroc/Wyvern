#ifndef QTIPCSERVER_H
#define QTIPCSERVER_H

// Define wyvern-Qt message queue name
#define WYVERNURI_QUEUE_NAME "wyvernURI"

void ipcScanRelay(int argc, char *argv[]);
void ipcInit(int argc, char *argv[]);

#endif // QTIPCSERVER_H
